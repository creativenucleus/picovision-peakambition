# Class prototype

class paCEffect():
    def __init__(self):
        pass

    def draw(self, gfx, display, lerpPos, tweenPos):
        pass

    def cleanup(self):
        pass

    def legend(self):
        return ""
    
    def detail(self):
        return ""
